# Handoff

## Status: complete

Series `model-comparison-2026-11-07-opencode` is finished. Baseline `model-comparison-2026-11-07` and production preset were not changed.

## Results
- Generation: 8/8 cells, 288/288 records; `_control/generation-audit.json` ok.
- Review: 60 packets, 288/288 cases.
- Audit: pre-registered 97/288 sample (`_control/audit-plan.json`, seed 20261108), 22 blinded packets, 47 adjudicated cases.
- Final: task_pass 175/288 (60.8%), product_pass 165/288 (57.3%); `_control/final-review-summary.json`.
- Langfuse: 8 raw experiments verified; 2479 gold scores published to 288 items and read back OK (`_control/gold-publish.json`).
- Report: `REPORT.md`; data: `_control/comparison.json`; judgments: `_control/final-judgments.json`.
- Archive: `../model-comparison-2026-11-07-opencode.tar.gz` + `.sha256`; per-file hashes in `_control/archive-manifest.json`.

## Key limitation
Profile comparison, not causal reasoning A/B. Single game/seed, single reviewer family, fresh-context audit is not independent human review.

## Do not
- Do not rerun into `generation/`.
- Do not overwrite the baseline or the Langfuse experiments.
- Do not treat audit agreement rates as population estimates.
