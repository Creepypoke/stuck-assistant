#!/usr/bin/env python3
"""Normalize schema deviations in raw audit reviews without overwriting them.

Every change is appended to _control/audit-normalization.jsonl. Only mechanical
type fixes are made: list/description values for boolean fields, actual code
values for codes_correct, and an adjacent-character transposition in a copied
binding hash. No judgment (true/false meaning) is changed.
"""
import json
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
RAW = CONTROL / 'audit-reviews'
OUT = CONTROL / 'audit-reviews-normalized'
LOG = CONTROL / 'audit-normalization.jsonl'


def main():
    selection = json.loads((CONTROL / 'audit-selection.json').read_text())
    packet_case = {}
    for cell, info in selection['cells'].items():
        for packet in info['packets']:
            body = json.loads((SERIES / packet['path']).read_text())
            for case in body['cases']:
                packet_case[(packet['packet_id'], case['case_id'])] = case
    rubric = json.loads((CONTROL / 'rubric.json').read_text())
    OUT.mkdir(exist_ok=True)
    changes = []
    for path in sorted(RAW.glob('*.json')):
        review = json.loads(path.read_text())
        pid = review['packet_id']
        for judgment in review['judgments']:
            cid = judgment['case_id']
            case = packet_case[(pid, cid)]

            for field in ('episode_error', 'unsupported_additions'):
                value = judgment.get(field)
                if isinstance(value, list):
                    judgment[field] = bool(value)
                    changes.append({'packet_id': pid, 'case_id': cid, 'field': field,
                                    'from': value, 'to': judgment[field],
                                    'reason': 'list value normalized to boolean presence'})
                elif value is None:
                    judgment[field] = False
                    changes.append({'packet_id': pid, 'case_id': cid, 'field': field,
                                    'from': None, 'to': False, 'reason': 'missing/None normalized to false'})
                elif isinstance(value, str):
                    judgment[field] = bool(value.strip())
                    changes.append({'packet_id': pid, 'case_id': cid, 'field': field,
                                    'from': value, 'to': judgment[field],
                                    'reason': 'description normalized to boolean presence'})

            codes = judgment.get('codes_correct')
            if isinstance(codes, (list, str)) and not isinstance(codes, bool):
                expected = rubric['codes'].get(cid)
                values = codes if isinstance(codes, list) else [codes]
                ok = bool(expected) and all(str(v) in [str(e) for e in expected] for v in values)
                judgment['codes_correct'] = ok
                changes.append({'packet_id': pid, 'case_id': cid, 'field': 'codes_correct',
                                'from': codes, 'to': ok,
                                'reason': 'reported code compared with rubric codes'})

            expected_binding = case['binding']
            got_binding = judgment.get('binding') or {}
            fixed = dict(got_binding)
            for key, expected_value in expected_binding.items():
                got = fixed.get(key)
                if got == expected_value:
                    continue
                if (isinstance(got, str) and isinstance(expected_value, str)
                        and len(got) == len(expected_value)
                        and sum(a != b for a, b in zip(got, expected_value)) == 2):
                    i = next(i for i, (a, b) in enumerate(zip(got, expected_value)) if a != b)
                    if i + 1 < len(got) and got[i] == expected_value[i + 1] and got[i + 1] == expected_value[i]:
                        fixed[key] = expected_value
                        changes.append({'packet_id': pid, 'case_id': cid, 'field': 'binding.' + key,
                                        'from': got, 'to': expected_value,
                                        'reason': 'adjacent-character transposition in copied hash'})
            judgment['binding'] = fixed
        (OUT / path.name).write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
    LOG.write_text(''.join(json.dumps(c, ensure_ascii=False) + '\n' for c in changes))
    print(json.dumps({'reviews': len(list(OUT.glob('*.json'))), 'changes': len(changes),
                      'fields': sorted({c['field'] for c in changes})}, ensure_ascii=False))


if __name__ == '__main__':
    main()
