#!/usr/bin/env python3
"""Non-benchmark diagnostic: verify native reasoning is observed for one model.

Uses the same server flags as run-model-comparison.py, a single tiny prompt,
and writes the request/response to _control/diagnostics. This is NOT part of
the benchmark and must never be counted in results.
"""
import json
import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERIES = HERE.parent.parent
REPO = SERIES.parent.parent.parent
BASE = REPO / 'backend/evaluation/model-comparison-2026-11-07'
PROFILES = {
    'qwen2b': (1.0, 20, .95, 0, 1.5),
    'minicpm5-1b': (.9, 40, .95, 0, 0),
    'gemma4-e2b': (1.0, 64, .95, 0, 0),
    'jamba3b': (.6, 40, .95, 0, 0),
}
PORT = 18084


def request(endpoint, payload=None, timeout=300):
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(f'http://127.0.0.1:{PORT}{endpoint}', data=data,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response)


def probe(name):
    weights = {w['name']: w for w in json.loads((BASE / 'weights.json').read_text())}
    temp, top_k, top_p, min_p, penalty = PROFILES[name]
    cmd = ['llama', 'serve', '-m', weights[name]['path'], '--host', '127.0.0.1',
           '--port', str(PORT), '--alias', name, '--jinja', '-c', '16384',
           '-np', '1', '-ngl', 'all', '--top-k', str(top_k), '--top-p', str(top_p),
           '--min-p', str(min_p), '--presence-penalty', str(penalty),
           '--reasoning', 'on', '--reasoning-format', 'deepseek']
    log_path = HERE / f'{name}-server.log'
    log = log_path.open('a')
    proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT)
    log.close()
    started = time.time()
    try:
        props = None
        for _ in range(300):
            if proc.poll() is not None:
                raise RuntimeError(f'server exited, see {log_path}')
            try:
                props = request('/props', timeout=3)
                break
            except Exception:
                time.sleep(1)
        payload = {'model': name,
                   'messages': [{'role': 'user', 'content': 'Ответь: сколько будет 2 + 2?'}],
                   'max_tokens': 512, 'temperature': temp, 'seed': 20261104,
                   'chat_template_kwargs': {'enable_thinking': True}}
        template = request('/apply-template', payload)
        response = request('/v1/chat/completions', payload)
        msg = response['choices'][0]['message']
        observed = bool(msg.get('reasoning_content') or msg.get('reasoning'))
        result = {
            'diagnostic': True,
            'model': name,
            'command': cmd,
            'port': PORT,
            'started_at': time.strftime('%Y-%m-%dT%H:%M:%S%z', time.localtime(started)),
            'load_and_probe_seconds': round(time.time() - started, 2),
            'props_summary': {k: props.get(k) for k in
                              ('model_path', 'model_alias', 'model_ftype', 'build_info')},
            'chat_template_has_enable_thinking': 'enable_thinking' in (props.get('chat_template') or ''),
            'payload': payload,
            'template': template,
            'response': response,
            'reasoning_observed': observed,
            'content': msg.get('content'),
            'reasoning_content': msg.get('reasoning_content') or msg.get('reasoning'),
            'finish_reason': response['choices'][0].get('finish_reason'),
            'usage': response.get('usage'),
        }
        (HERE / f'{name}-probe.json').write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        return result
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()


if __name__ == '__main__':
    name = sys.argv[1]
    r = probe(name)
    print(json.dumps({'model': name, 'reasoning_observed': r['reasoning_observed'],
                      'finish_reason': r['finish_reason'],
                      'reasoning_chars': len(r['reasoning_content'] or ''),
                      'content': (r['content'] or '')[:200]}, ensure_ascii=False))
