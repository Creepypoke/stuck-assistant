#!/usr/bin/env python3
"""Build compact adjudication dossiers for audit/first-review disagreements."""
import json
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
FIELDS = ['task_pass', 'strict_pass', 'product_pass', 'episode_error',
          'unsupported_additions', 'spoiler', 'language_ok', 'codes_correct',
          'sequences_correct']


def main():
    summary = json.loads((CONTROL / 'audit-summary.json').read_text())
    disagreeing = sorted({(d['cell'], d['case_id']) for d in summary['disagreements']})
    selection = json.loads((CONTROL / 'audit-selection.json').read_text())
    packets = {}
    for cell, info in selection['cells'].items():
        for packet in info['packets']:
            body = json.loads((SERIES / packet['path']).read_text())
            for case in body['cases']:
                packets[(cell, case['case_id'])] = case
    first = {}
    for path in sorted((CONTROL / 'reviews').glob('*.json')):
        review = json.loads(path.read_text())
        for judgment in review['judgments']:
            for (cell, cid), case in packets.items():
                if cid == judgment['case_id'] and cell not in [k[0] for k in first.get((cid,), [])]:
                    pass
            # resolve by case id later using manifests
    # build case->cell->judgment from packet manifests
    for manifest_path in sorted((CONTROL / 'packets').glob('*/manifest.json')):
        manifest = json.loads(manifest_path.read_text())
        pid_cell = {p['packet_id']: manifest['cell'] for p in manifest['packets']}
        for path in sorted((CONTROL / 'reviews').glob('*.json')):
            review = json.loads(path.read_text())
            if review['packet_id'] not in pid_cell:
                continue
            cell = pid_cell[review['packet_id']]
            for judgment in review['judgments']:
                first[(cell, judgment['case_id'])] = judgment
    audit = {}
    for path in sorted((CONTROL / 'audit-reviews-normalized').glob('*.json')):
        review = json.loads(path.read_text())
        for judgment in review['judgments']:
            audit[(judgment['case_id'],)] = judgment
    by_pid = {}
    for cell, info in selection['cells'].items():
        for packet in info['packets']:
            for cid in packet['case_ids']:
                by_pid[(cell, cid)] = packet['packet_id']
    audit_case = {}
    for path in sorted((CONTROL / 'audit-reviews-normalized').glob('*.json')):
        review = json.loads(path.read_text())
        for judgment in review['judgments']:
            audit_case[(by_pid_cell(review['packet_id'], selection), judgment['case_id'])] = judgment

    out = []
    for index, key in enumerate(disagreeing, 1):
        case, f, a = packets[key], first[key], audit_case[key]
        differing = [x for x in FIELDS if f.get(x) != a.get(x)]
        out.append(f"## {index}. {key[0]} / {key[1]}\n")
        out.append(f"Q: {case['question']}\n\n")
        out.append(f"Expected: {case['expected']}\n\n")
        for evidence in case['evidence']:
            out.append(f"Evidence: {evidence.get('quote')}\n\n")
        out.append(f"Answer:\n{case['answer']}\n\n")
        out.append('First review: ' + json.dumps({x: f.get(x) for x in FIELDS}, ensure_ascii=False) + '\n\n')
        out.append('First reason: ' + str(f.get('reason')) + '\n\n')
        if f.get('notes'):
            out.append('First notes: ' + str(f.get('notes')) + '\n\n')
        out.append('Audit: ' + json.dumps({x: a.get(x) for x in FIELDS}, ensure_ascii=False) + '\n\n')
        out.append('Audit reason: ' + str(a.get('reason')) + '\n\n')
        if a.get('notes'):
            out.append('Audit notes: ' + str(a.get('notes')) + '\n\n')
        out.append('Differing fields: ' + ', '.join(differing) + '\n\n---\n\n')
    (CONTROL / 'adjudication-dossier.md').write_text(''.join(out))
    print(f'{len(disagreeing)} cases, dossier bytes={len("".join(out).encode())}')


def by_pid_cell(pid, selection):
    for cell, info in selection['cells'].items():
        for packet in info['packets']:
            if packet['packet_id'] == pid:
                return cell
    raise KeyError(pid)


if __name__ == '__main__':
    main()
