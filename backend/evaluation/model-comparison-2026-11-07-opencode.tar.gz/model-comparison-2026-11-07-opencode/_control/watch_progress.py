#!/usr/bin/env python3
"""Wait until the number of completed generation cells increases or the runner exits.

Reads only generation/status.json (small). Prints a compact summary.
"""
import json
import os
import sys
import time
from pathlib import Path

SERIES = Path(__file__).resolve().parent.parent
STATUS = SERIES / 'generation/status.json'
PID = int(sys.argv[1])
SINCE = int(sys.argv[2]) if len(sys.argv) > 2 else 0
INTERVAL = 30


def completed():
    try:
        d = json.loads(STATUS.read_text())
    except Exception:
        return 0, [], 'running'
    jobs = d.get('jobs', [])
    done = [j for j in jobs if j.get('status') in ('generated', 'incomplete', 'failed')]
    return len(done), jobs, d.get('status')


def alive(pid):
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


while True:
    n, jobs, status = completed()
    if n > SINCE or not alive(PID) or status in ('failed', 'stopped_user', 'generated'):
        print(json.dumps({'completed_cells': n, 'runner_status': status,
                          'runner_alive': alive(PID),
                          'cells': [{'model': j.get('model'), 'kind': j.get('kind'),
                                     'status': j.get('status'), 'records': j.get('records'),
                                     'errors': j.get('errors'), 'exit_code': j.get('exit_code')}
                                    for j in jobs]}, ensure_ascii=False))
        sys.exit(0)
    time.sleep(INTERVAL)
