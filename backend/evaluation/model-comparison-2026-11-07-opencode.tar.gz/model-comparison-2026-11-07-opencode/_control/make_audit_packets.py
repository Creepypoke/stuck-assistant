#!/usr/bin/env python3
"""Select the pre-registered audit sample and build blinded audit packets.

Reads first-review metadata only to select cases (census of ambiguous flags +
seeded 20% random per cell). Audit packet files contain no model/cell name and
no first-review judgment; the cell mapping lives only in the selection manifest.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path

import make_review_packets as mrp

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
GENERATION = SERIES / 'generation' / 'runs'
CENSUS_REASON = 'ambiguous-first-review'
RANDOM_REASON = 'seeded-random'


def sha_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def sha_file(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def packet_map():
    mapping = {}
    for manifest_path in sorted((CONTROL / 'packets').glob('*/manifest.json')):
        manifest = json.loads(manifest_path.read_text())
        for packet in manifest['packets']:
            for case_id in packet['case_ids']:
                mapping[(manifest['cell'], case_id)] = packet['packet_id']
    return mapping


def reviews_by_cell(packets):
    out = {}
    for review_path in sorted((CONTROL / 'reviews').glob('*.json')):
        review = json.loads(review_path.read_text())
        for judgment in review['judgments']:
            out[(review['packet_id'], judgment['case_id'])] = judgment
    by_cell = {}
    for (packet_id, case_id), judgment in out.items():
        cell = next(c for (c, cid), pid in packets.items() if pid == packet_id and cid == case_id)
        by_cell.setdefault(cell, {})[case_id] = judgment
    return by_cell


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--selection-out', type=Path, required=True)
    ap.add_argument('--plan', type=Path, default=CONTROL / 'audit-plan.json')
    args = ap.parse_args()

    plan = json.loads(args.plan.read_text())
    seed = plan['sampling']['seed']
    packets = packet_map()
    if len(packets) != 288:
        raise SystemExit(f'expected 288 first-review case bindings, got {len(packets)}')
    reviews = reviews_by_cell(packets)
    if sum(len(v) for v in reviews.values()) != 288:
        raise SystemExit('review coverage is not 288 cases')

    questions = {q['id']: q for q in json.loads(mrp.QUESTIONS.read_text())}
    order = {q['id']: i for i, q in enumerate(json.loads(mrp.QUESTIONS.read_text()))}
    protocol_sha = sha_file(mrp.PROTOCOL)
    rubric_sha = sha_file(mrp.RUBRIC)
    rubric = json.loads(mrp.RUBRIC.read_text())

    args.out.mkdir(parents=True, exist_ok=True)
    selection = {
        'schema': 'model-comparison-audit-selection-v1',
        'plan_path': os.path.relpath(args.plan.resolve(), SERIES),
        'plan_sha256': sha_file(args.plan),
        'seed': seed,
        'population_cases': 288,
        'cells': {},
    }
    packet_records = []
    total = 0
    for cell in sorted(reviews):
        cell_reviews = reviews[cell]
        census = sorted((cid for cid, j in cell_reviews.items() if j.get('ambiguous_judgment')),
                        key=lambda cid: order[cid])
        remaining = [cid for cid in cell_reviews if cid not in set(census)]
        remaining.sort(key=lambda cid: sha_text(f'{seed}|audit-sample-v1|{cell}|{cid}'))
        take = math.ceil(plan['sampling']['random_stratum']['target_fraction_of_remaining'] * len(remaining))
        random_pick = sorted(remaining[:take], key=lambda cid: order[cid])
        ranks = {cid: i + 1 for i, cid in enumerate(remaining)}
        chosen = [(cid, CENSUS_REASON) for cid in census] + [(cid, RANDOM_REASON) for cid in random_pick]
        chosen.sort(key=lambda item: order[item[0]])
        if len({cid for cid, _ in chosen}) != len(chosen):
            raise SystemExit(f'duplicate audit sample in {cell}')

        records, origin, results_sha = mrp.load_records(GENERATION / cell)
        by_case = {r['case']: r for r in records}
        cases = [mrp.case_payload(by_case[cid], questions[cid], rubric_sha, protocol_sha) for cid, _ in chosen]

        packed, current, size = [], [], 0
        for case in cases:
            encoded = len(json.dumps(case, ensure_ascii=False).encode())
            too_big = current and (size + encoded > mrp.TARGET_BYTES or len(current) >= 5)
            if too_big and len(current) >= 3:
                packed.append(current)
                current, size = [], 0
            current.append(case)
            size += encoded
        if current:
            packed.append(current)

        cell_packets = []
        for index, group in enumerate(packed, 1):
            pid = 'audit-' + sha_text(f'{seed}|{cell}|{index}|{results_sha}')[:12]
            packet = {
                'packet_id': pid,
                'rubric': rubric,
                'reviewer_instructions': {
                    'read_full_answer': True,
                    'source': 'expected + evidence quotes + retrieved_context_text',
                    'reasoning': 'excluded by design',
                    'output': 'one JSON judgment per case_id',
                },
                'cases': group,
            }
            path = args.out / f'{pid}.json'
            data = json.dumps(packet, ensure_ascii=False, indent=2).encode() + b'\n'
            path.write_bytes(data)
            cell_packets.append({
                'packet_id': pid,
                'path': os.path.relpath(path.resolve(), SERIES),
                'sha256': hashlib.sha256(data).hexdigest(),
                'case_ids': [c['case_id'] for c in group],
                'utf8_bytes': len(data),
            })
            packet_records.append(cell_packets[-1])
        selection['cells'][cell] = {
            'source': os.path.relpath(origin.resolve(), SERIES),
            'results_sha256': results_sha,
            'cases': len(cell_reviews),
            'ambiguous_cases': [cid for cid in census],
            'random_cases': random_pick,
            'random_pool': len(remaining),
            'random_ranks': {cid: ranks[cid] for cid in random_pick},
            'selected_cases': [cid for cid, _ in chosen],
            'packets': cell_packets,
        }
        total += len(chosen)

    selection['selected_cases'] = total
    selection['packets'] = len(packet_records)
    args.selection_out.write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'selected_cases': total, 'packets': len(packet_records),
                      'per_cell': {c: len(v['selected_cases']) for c, v in selection['cells'].items()}},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
