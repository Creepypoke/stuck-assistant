#!/usr/bin/env python3
"""Publish post-audit gold scores to existing Langfuse experiment observations.

Reuses langfuse/pipeline.py's Client and observation-id derivation. Scores are
posted to the root observation of each imported case; nothing is re-imported and
existing experiments are not modified except by adding scores. Every expected
score is read back from the experiment-items API and compared.
"""
import argparse
import hashlib
import json
import sys
import time
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
ROOT = SERIES.parent.parent.parent
sys.path.insert(0, str(ROOT / 'langfuse'))
import pipeline  # noqa: E402

MANUAL = {
    'task_pass': 'task_pass',
    'episode_error': 'episode_error',
    'unsupported_addition': 'unsupported_additions',
    'spoiler': 'spoiler',
    'exact_code': 'codes_correct',
    'exact_sequence': 'sequences_correct',
    'answer_language_match': 'language_ok',
}


def digest(value, size=64):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()[:size]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--out', type=Path, default=CONTROL / 'gold-publish.json')
    args = ap.parse_args()

    publish = json.loads((CONTROL / 'publish.json').read_text())
    final = json.loads((CONTROL / 'final-judgments.json').read_text())
    judgments = {(c['cell'], c['case_id']): c['judgment'] for c in final['cases']}
    if len(judgments) != 288:
        raise SystemExit(f'expected 288 final judgments, got {len(judgments)}')
    rubric_sha = hashlib.sha256((CONTROL / 'rubric.json').read_bytes()).hexdigest()
    client = None if args.dry_run else pipeline.Client()
    results = []
    all_scores = []
    for cell in publish['raw_imports']:
        name = cell['cell']
        state_paths = sorted((SERIES / 'generation' / 'runs' / name).glob('.langfuse-*.json'))
        if len(state_paths) != 1:
            raise SystemExit(f'expected one import state in {name}, got {state_paths}')
        state = json.loads(state_paths[0].read_text())
        experiment_ids = [e['id'] for e in state['experiments']]
        if experiment_ids != cell['experiment_ids']:
            raise SystemExit(f'experiment id mismatch for {name}: {experiment_ids} != {cell["experiment_ids"]}')
        experiment_id = experiment_ids[0]
        records = json.loads((SERIES / 'generation' / 'runs' / name / 'results.json').read_text())
        scores = []
        for record in records:
            case_id = record['case']
            judgment = judgments[(name, case_id)]
            trace_id = digest([experiment_id, case_id], 32)
            observation_id = digest([trace_id, 'root'], 16)
            values = {'gold_strict_pass': judgment['strict_pass'],
                      'gold_product_pass': judgment['product_pass'],
                      'gold_truncated': judgment['truncated']}
            for score_name, field in MANUAL.items():
                value = judgment.get(field)
                if value is not None:
                    values[score_name] = value
            for score_name, value in values.items():
                scores.append({
                    'id': digest([trace_id, score_name]),
                    'traceId': trace_id,
                    'observationId': observation_id,
                    'name': score_name,
                    'value': int(bool(value)),
                    'dataType': 'BOOLEAN',
                    'environment': 'evaluation',
                    'timestamp': datetime.fromtimestamp(state['start_ns'] / 1e9, timezone.utc).isoformat(),
                    'comment': (f'Gold source review, final after audit adjudication; rubric {rubric_sha[:12]}; '
                                f'reviewer local-coding-medium; case {cell["cell"]}/{case_id}'),
                })
        if not args.dry_run:
            for offset in range(0, len(scores), 50):
                client.request('/api/public/scores', scores[offset:offset + 50])
        all_scores.extend(scores)
        results.append({
            'cell': name,
            'experiment_id': experiment_id,
            'experiment_name': cell['experiment_names'][0],
            'cases': len(records),
            'scores': len(scores),
            'score_names': sorted({s['name'] for s in scores}),
            'posted': not args.dry_run,
        })

    verification = None
    if not args.dry_run:
        deadline = time.monotonic() + 60
        while True:
            actual = {}
            rows_total = 0
            for item in results:
                state = json.loads(sorted((SERIES / 'generation' / 'runs' / item['cell']).glob('.langfuse-*.json'))[0].read_text())
                since = datetime.fromtimestamp(state['start_ns'] / 1e9 - 60, timezone.utc).isoformat()
                query = {'fromStartTime': since, 'experimentId': item['experiment_id'],
                         'fields': 'core,dataset,io,scores', 'limit': 100}
                while True:
                    page = client.request('/api/public/experiment-items?' + urllib.parse.urlencode(query))
                    for row in page['data']:
                        rows_total += 1
                        for score in row.get('scores', []):
                            actual[(row['id'], score['name'])] = score['value']
                    cursor = page.get('meta', {}).get('cursor')
                    if not cursor:
                        break
                    query['cursor'] = cursor
            missing = [s for s in all_scores
                       if actual.get((s['observationId'], s['name'])) != bool(s['value'])]
            if rows_total == 288 and not missing:
                verification = {'ok': True, 'items': rows_total, 'scores': len(all_scores),
                                'experiments': len(results), 'verified_at': datetime.now(timezone.utc).isoformat()}
                break
            if time.monotonic() >= deadline:
                verification = {'ok': False, 'items': rows_total, 'scores': len(all_scores),
                                'missing': len(missing),
                                'examples': missing[:5],
                                'verified_at': datetime.now(timezone.utc).isoformat()}
                break
            time.sleep(2)

    document = {
        'schema': 'model-comparison-gold-publish-v1',
        'rubric_sha256': rubric_sha,
        'final_judgments_sha256': hashlib.sha256((CONTROL / 'final-judgments.json').read_bytes()).hexdigest(),
        'dry_run': args.dry_run,
        'cells': results,
        'total_scores': len(all_scores),
        'verification': verification,
        'score_definitions': {
            'gold_strict_pass': 'strict_pass',
            'gold_product_pass': 'task_pass AND language_ok',
            'gold_truncated': 'any completion attempt ended with finish_reason=length',
            **{k: v for k, v in MANUAL.items()},
        },
    }
    args.out.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'dry_run': args.dry_run, 'cells': len(results),
                      'scores': len(all_scores), 'verification': verification}, ensure_ascii=False))
    if verification is not None and not verification['ok']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
