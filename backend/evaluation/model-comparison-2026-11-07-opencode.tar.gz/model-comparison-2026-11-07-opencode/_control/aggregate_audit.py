#!/usr/bin/env python3
"""Validate fresh-context audit reviews and compare them with first reviews.

Fails nonzero on missing/orphaned reviews, packet hash mismatch, binding
mismatch, missing cases, or malformed judgments. Writes an agreement summary.
"""
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
FIELDS = ['task_pass', 'strict_pass', 'product_pass', 'episode_error',
          'unsupported_additions', 'spoiler', 'language_ok', 'codes_correct',
          'sequences_correct']
REQUIRED = ['case_id', 'binding', 'task_pass', 'strict_pass', 'product_pass',
            'facts_correct', 'codes_correct', 'sequences_correct', 'episode_error',
            'unsupported_additions', 'spoiler', 'ambiguous_handling', 'language_ok',
            'source_exact_ui', 'runtime_success', 'truncated',
            'answering_clarification', 'reason', 'source_quote_or_span',
            'ambiguous_judgment', 'notes']


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selection', type=Path, default=CONTROL / 'audit-selection.json')
    ap.add_argument('--reviews', type=Path, default=CONTROL / 'audit-reviews')
    ap.add_argument('--first-reviews', type=Path, default=CONTROL / 'reviews')
    ap.add_argument('--packets', type=Path, default=CONTROL / 'packets')
    ap.add_argument('--out', type=Path, default=CONTROL / 'audit-summary.json')
    args = ap.parse_args()

    selection = json.loads(args.selection.read_text())
    planned = {}
    packet_meta = {}
    for cell, info in selection['cells'].items():
        for packet in info['packets']:
            packet_meta[packet['packet_id']] = (cell, packet)
            packet_path = SERIES / packet['path']
            data = packet_path.read_bytes()
            if sha_bytes(data) != packet['sha256']:
                raise SystemExit(f'packet file hash mismatch: {packet["packet_id"]}')
            body = json.loads(data)
            for case in body['cases']:
                planned[(cell, case['case_id'])] = case['binding']

    first = {}
    for manifest_path in sorted(args.packets.glob('*/manifest.json')):
        manifest = json.loads(manifest_path.read_text())
        for packet in manifest['packets']:
            for cid in packet['case_ids']:
                meta = next(p for p in manifest['packets'] if p['packet_id'] == packet['packet_id'])
                first[(manifest['cell'], cid)] = meta['packet_id']
    first_judgments = {}
    for path in sorted(args.first_reviews.glob('*.json')):
        review = json.loads(path.read_text())
        for j in review['judgments']:
            cell = next(c for (c, cid), pid in first.items() if pid == review['packet_id'] and cid == j['case_id'])
            first_judgments[(cell, j['case_id'])] = j

    problems = []
    audit = {}
    seen_packets = set()
    for path in sorted(args.reviews.glob('*.json')):
        review = json.loads(path.read_text())
        pid = review.get('packet_id')
        if pid not in packet_meta:
            problems.append(f'orphan audit review: {pid}')
            continue
        if pid in seen_packets:
            problems.append(f'duplicate audit packet: {pid}')
        seen_packets.add(pid)
        cell, packet = packet_meta[pid]
        if review.get('packet_sha256') != packet['sha256']:
            problems.append(f'packet hash mismatch in review: {pid}')
        packet_body = json.loads((SERIES / packet['path']).read_text())
        expected = [c['case_id'] for c in packet_body['cases']]
        got = [j.get('case_id') for j in review.get('judgments', [])]
        if got != expected:
            problems.append(f'case order/coverage mismatch in {pid}: {got} != {expected}')
        for j in review.get('judgments', []):
            key = (cell, j.get('case_id'))
            if key in audit:
                problems.append(f'duplicate audit judgment: {key}')
            for field in REQUIRED:
                if field not in j:
                    problems.append(f'missing field {field} in {key}')
            if j.get('binding') != planned.get(key):
                problems.append(f'binding mismatch: {key}')
            for field in ('task_pass', 'strict_pass', 'product_pass', 'facts_correct',
                          'episode_error', 'unsupported_additions', 'spoiler',
                          'language_ok', 'runtime_success', 'truncated',
                          'answering_clarification', 'ambiguous_judgment'):
                if not isinstance(j.get(field), bool):
                    problems.append(f'non-boolean {field} in {key}')
            for field in ('codes_correct', 'sequences_correct', 'source_exact_ui'):
                if j.get(field) is not None and not isinstance(j.get(field), bool):
                    problems.append(f'non-boolean/null {field} in {key}')
            audit[key] = j
    missing = sorted(set(planned) - set(audit))
    if missing:
        problems.append(f'missing audit judgments: {len(missing)} ({missing[:10]})')

    per_cell = defaultdict(lambda: {'cases': 0, 'exact': 0, 'fields': defaultdict(lambda: [0, 0])})
    disagreements = []
    for key in sorted(planned):
        if key not in audit or key not in first_judgments:
            continue
        cell, cid = key
        a, f = audit[key], first_judgments[key]
        stats = per_cell[cell]
        stats['cases'] += 1
        exact = True
        for field in FIELDS:
            stats['fields'][field][1] += 1
            if a.get(field) == f.get(field):
                stats['fields'][field][0] += 1
            else:
                exact = False
                disagreements.append({'cell': cell, 'case_id': cid, 'field': field,
                                      'first_review': f.get(field),
                                      'audit': a.get(field),
                                      'first_reason': f.get('reason'),
                                      'audit_reason': a.get('reason'),
                                      'audit_source': a.get('source_quote_or_span')})
        if exact:
            stats['exact'] += 1
    total_cases = sum(s['cases'] for s in per_cell.values())
    total_exact = sum(s['exact'] for s in per_cell.values())
    summary = {
        'schema': 'model-comparison-audit-summary-v1',
        'ok': not problems,
        'problems': problems,
        'planned_cases': len(planned),
        'audited_cases': len(audit),
        'packets_planned': len(packet_meta),
        'packets_reviewed': len(seen_packets),
        'exact_agreement': total_exact,
        'exact_agreement_rate': round(total_exact / total_cases, 4) if total_cases else None,
        'cells': {
            cell: {'cases': s['cases'], 'exact': s['exact'],
                   'exact_rate': round(s['exact'] / s['cases'], 4),
                   'fields': {f: {'agree': v[0], 'total': v[1],
                                  'rate': round(v[0] / v[1], 4)}
                              for f, v in s['fields'].items()}}
            for cell, s in sorted(per_cell.items())
        },
        'field_agreement': {f: {'agree': sum(s['fields'][f][0] for s in per_cell.values()),
                                'total': sum(s['fields'][f][1] for s in per_cell.values())}
                            for f in FIELDS},
        'disagreements': disagreements,
    }
    for field, value in summary['field_agreement'].items():
        value['rate'] = round(value['agree'] / value['total'], 4) if value['total'] else None
    args.out.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'ok': not problems, 'problems': len(problems),
                      'audited': len(audit), 'exact_agreement': total_exact,
                      'disagreements': len(disagreements)}, ensure_ascii=False))
    raise SystemExit(1 if problems else 0)


if __name__ == '__main__':
    main()
