#!/usr/bin/env python3
"""Validate review outputs and aggregate them per generation cell.

Supports either one packets/manifest.json or a directory of <cell>/manifest.json.
Fails (nonzero) on missing, duplicate, orphaned, hash-mismatched or
binding-mismatched judgments. Every planned case is in the denominator,
including empty/truncated/error answers.
"""
import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--packets', type=Path, required=True)
    ap.add_argument('--reviews', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    if (args.packets / 'manifest.json').exists():
        manifests = [json.loads((args.packets / 'manifest.json').read_text())]
    else:
        manifests = [json.loads(p.read_text()) for p in sorted(args.packets.glob('*/manifest.json'))]
    all_packets = [meta for manifest in manifests for meta in manifest['packets']]
    pid_to_cell = {meta['packet_id']: meta['cell'] for meta in all_packets}
    problems = []
    expected = {}
    packets = {}
    for meta in all_packets:
        p = Path(meta['path'])
        b = p.read_bytes()
        if sha_bytes(b) != meta['sha256']:
            problems.append(f'packet hash mismatch: {meta["packet_id"]}')
        packet = json.loads(b)
        packets[meta['packet_id']] = packet
        for case in packet['cases']:
            key = (meta['cell'], case['case_id'])
            if key in expected:
                problems.append(f'duplicate case in packets: {key}')
            expected[key] = (meta['packet_id'], case['binding'])
    judgments = {}
    seen_packets = set()
    for p in sorted(args.reviews.glob('*.json')):
        rev = json.loads(p.read_text())
        pid = rev.get('packet_id')
        if pid not in packets:
            problems.append(f'orphan review packet: {pid}')
            continue
        if pid in seen_packets:
            problems.append(f'duplicate review packet: {pid}')
        seen_packets.add(pid)
        packet = packets[pid]
        meta = next(m for m in all_packets if m['packet_id'] == pid)
        if rev.get('packet_sha256') != meta['sha256']:
            problems.append(f'review packet hash mismatch: {pid}')
        case_ids = {c['case_id'] for c in packet['cases']}
        got = {j.get('case_id') for j in rev.get('judgments', [])}
        if got != case_ids:
            problems.append(f'case coverage mismatch in {pid}: missing={sorted(case_ids-got)} extra={sorted(got-case_ids)}')
        for j in rev.get('judgments', []):
            key = (meta['cell'], j.get('case_id'))
            if key in judgments:
                problems.append(f'duplicate judgment: {key}')
            if key in expected and j.get('binding') != expected[key][1]:
                problems.append(f'binding mismatch: {key}')
            judgments[key] = j
    missing = sorted(set(expected) - set(judgments))
    if missing:
        problems.append(f'missing judgments: {len(missing)} ({missing[:10]})')
    cells = defaultdict(list)
    for cell, cid in expected:
        cells[cell].append(cid)

    def count(items, key, value=True):
        return sum(1 for cid in items if judgments.get((cell, cid), {}).get(key) == value)

    summary = {'schema': 'model-comparison-review-summary-v1',
               'packets': len(all_packets),
               'cases_expected': len(expected), 'cases_reviewed': len(judgments),
               'problems': problems, 'cells': {}, 'overall': {}}
    total = []
    for cell, cids in sorted(cells.items()):
        c = {'cases': len(cids),
             'task_pass': count(cids, 'task_pass'),
             'strict_pass': count(cids, 'strict_pass'),
             'product_pass': count(cids, 'product_pass'),
             'errors': count(cids, 'runtime_success', False),
             'truncated': count(cids, 'truncated'),
             'episode_error': count(cids, 'episode_error'),
             'unsupported_additions': count(cids, 'unsupported_additions'),
             'spoiler': count(cids, 'spoiler'),
             'language_fail': count(cids, 'language_ok', False),
             'codes_checked': sum(1 for cid in cids if judgments.get((cell, cid), {}).get('codes_correct') is not None),
             'codes_correct': count(cids, 'codes_correct'),
             'sequences_checked': sum(1 for cid in cids if judgments.get((cell, cid), {}).get('sequences_correct') is not None),
             'sequences_correct': count(cids, 'sequences_correct'),
             'ambiguous_judgments': count(cids, 'ambiguous_judgment')}
        c['task_rate'] = round(c['task_pass'] / c['cases'], 4) if c['cases'] else None
        c['product_rate'] = round(c['product_pass'] / c['cases'], 4) if c['cases'] else None
        summary['cells'][cell] = c
        total.extend((cell, cid) for cid in cids)
    if total:
        o = {'cases': len(total),
             'task_pass': sum(1 for k in total if judgments.get(k, {}).get('task_pass')),
             'strict_pass': sum(1 for k in total if judgments.get(k, {}).get('strict_pass')),
             'product_pass': sum(1 for k in total if judgments.get(k, {}).get('product_pass')),
             'errors': sum(1 for k in total if judgments.get(k, {}).get('runtime_success') is False),
             'truncated': sum(1 for k in total if judgments.get(k, {}).get('truncated'))}
        o['task_rate'] = round(o['task_pass'] / o['cases'], 4)
        o['product_rate'] = round(o['product_pass'] / o['cases'], 4)
        summary['overall'] = o
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'ok': not problems, 'problems': len(problems),
                      'cases': len(expected), 'reviewed': len(judgments),
                      'cells': len(cells)}, ensure_ascii=False))
    raise SystemExit(1 if problems else 0)


if __name__ == '__main__':
    main()
