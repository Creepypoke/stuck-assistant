#!/usr/bin/env python3
"""Build comparison.json from final judgments, runtime artifacts and baseline."""
import glob
import hashlib
import json
import statistics
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
BASELINE = SERIES.parent / 'model-comparison-2026-11-07'


def p95(values):
    values = sorted(values)
    if not values:
        return None
    index = max(0, min(len(values) - 1, round(0.95 * len(values)) - 1))
    return values[index]


def main():
    final = json.loads((CONTROL / 'final-judgments.json').read_text())
    summary = json.loads((CONTROL / 'final-review-summary.json').read_text())
    baseline = json.loads((BASELINE / 'comparison.json').read_text())
    baseline_judgments = json.loads((BASELINE / 'judgments.json').read_text())
    audit = json.loads((CONTROL / 'audit-summary.json').read_text())
    protocol = json.loads((CONTROL / 'protocol.json').read_text())
    cells = {}
    by_cell = {}
    for item in final['cases']:
        by_cell.setdefault(item['cell'], []).append(item['judgment'])
    for cell, judgments in sorted(by_cell.items()):
        model, kind = cell.rsplit('-', 1)
        metrics = summary['cells'][cell]
        records = json.loads((SERIES / 'generation' / 'runs' / cell / 'results.json').read_text())
        attempts = [a for r in records for a in (r['debug'].get('completion_attempts') or [])]
        seconds = [sum(a.get('seconds') or 0 for a in r['debug'].get('completion_attempts') or [])
                   for r in records]
        base = baseline['models'][model][kind]['metrics']
        base_task = {cid: True for cid in baseline_judgments[cell]['pass'].split()}
        new_task = {item['case_id']: item['judgment']['task_pass'] for item in final['cases']
                    if item['cell'] == cell}
        improved = sorted(cid for cid in new_task if new_task[cid] and not base_task.get(cid, False))
        worsened = sorted(cid for cid in new_task if base_task.get(cid, False) and not new_task[cid])
        cells[cell] = {
            'model': model,
            'kind': kind,
            'cases': metrics['cases'],
            'metrics': {
                'task_pass': {'numerator': metrics['task_pass'], 'denominator': metrics['cases'],
                              'value': metrics['task_rate']},
                'strict_pass': {'numerator': metrics['strict_pass'], 'denominator': metrics['cases'],
                                'value': round(metrics['strict_pass'] / metrics['cases'], 4)},
                'product_pass': {'numerator': metrics['product_pass'], 'denominator': metrics['cases'],
                                 'value': metrics['product_rate']},
                'answer_language_match': {'numerator': metrics['cases'] - metrics['language_fail'],
                                          'denominator': metrics['cases']},
                'exact_code': {'numerator': metrics['codes_correct'], 'denominator': metrics['codes_checked']},
                'exact_sequence': {'numerator': metrics['sequences_correct'],
                                   'denominator': metrics['sequences_checked']},
                'episode_error': {'numerator': metrics['episode_error'], 'denominator': metrics['cases']},
                'unsupported_addition': {'numerator': metrics['unsupported_additions'],
                                         'denominator': metrics['cases']},
                'spoiler': {'numerator': metrics['spoiler'], 'denominator': metrics['cases']},
                'runtime_success': {'numerator': metrics['cases'] - metrics['errors'],
                                    'denominator': metrics['cases']},
                'truncated': {'numerator': metrics['truncated'], 'denominator': metrics['cases']},
            },
            'generation': {
                'attempts': len(attempts),
                'cases_with_retry': sum(1 for r in records
                                        if len(r['debug'].get('completion_attempts') or []) > 1),
                'completion_tokens_all_attempts': sum(a.get('completion_tokens') or 0 for a in attempts),
                'completion_tokens_final_attempts': sum(
                    (r['debug']['completion_attempts'] or [{}])[-1].get('completion_tokens') or 0
                    for r in records),
                'reasoning_content_present': sum(1 for a in attempts if a.get('reasoning_content')),
                'reasoning_tokens_reported': sum(1 for a in attempts if a.get('reasoning_tokens') is not None),
                'generation_seconds_p50': round(statistics.median(seconds), 1),
                'generation_seconds_p95': round(p95(seconds), 1),
                'generation_seconds_max': round(max(seconds), 1),
            },
            'baseline': {
                'task_pass': base['task_pass']['value'],
                'product_pass': base['product_pass']['value'],
                'answer_language_match': base['answer_language_match']['value'],
                'exact_code': base['exact_code']['value'],
                'exact_sequence': base['exact_sequence']['value'],
                'note': 'baseline used different token budget/sampling and no native reasoning toggle',
            },
            'delta_vs_baseline_task_pp': round((metrics['task_rate'] - base['task_pass']['value']) * 100, 1),
            'delta_vs_baseline_product_pp': round((metrics['product_rate'] - base['product_pass']['value']) * 100, 1),
            'improved_questions': improved,
            'worsened_questions': worsened,
        }
    document = {
        'schema': 'model-comparison-opencode-v1',
        'series': SERIES.name,
        'protocol_sha256': hashlib.sha256((CONTROL / 'protocol.json').read_bytes()).hexdigest(),
        'cases': 38,
        'oracle_cases': 34,
        'seed': protocol.get('seed'),
        'models_run': ['qwen2b', 'minicpm5-1b', 'gemma4-e2b', 'jamba3b'],
        'controls_not_rerun': ['gemma3-4b', 'phi4-mini'],
        'baseline_series': BASELINE.name,
        'cells': cells,
        'overall': summary['overall'],
        'audit': {
            'sampled_cases': audit['audited_cases'],
            'population_cases': audit['planned_cases'],
            'census': 'all 46 first-review ambiguous_judgment cases',
            'random': 'ceil(20%) of remaining cases per cell, seed 20261108',
            'exact_all_field_agreement': audit['exact_agreement'],
            'exact_all_field_agreement_rate': audit['exact_agreement_rate'],
            'field_agreement': audit['field_agreement'],
            'adjudicated_cases': 47,
            'corrections': summary['corrections'],
        },
        'evaluation_rules': {
            'task_pass': 'all requested facts, correct episode/conditions/order, no material unsupported additions or unnecessary spoilers',
            'strict_pass': 'task_pass plus source-exact UI labels',
            'product_pass': 'task_pass AND language_ok',
            'truncated': 'any completion attempt ended with finish_reason=length; such a case fails task/strict/product per the frozen rubric',
            'errors': 'record-level evaluator/generation error only; truncation is reported separately',
        },
        'limitations': [
            'One game, one seed, one diagnostic 38-question set.',
            'Profile comparison: token budget, context window and sampling differ from baseline, so differences cannot be attributed to the reasoning flag.',
            'Single reviewer family; fresh-context audit is not independent human review.',
            'Audit oversamples borderline cases; agreement rates are not population estimates.',
            'Latency was measured under this sequential local run only and is not comparable to baseline parallel or production timings.',
            'Reasoning tokens were not reported separately by the server; only presence of reasoning_content is recorded.',
        ],
    }
    (CONTROL / 'comparison.json').write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({c: {'task': v['metrics']['task_pass'],
                          'delta_pp': v['delta_vs_baseline_task_pp'],
                          'improved': len(v['improved_questions']),
                          'worsened': len(v['worsened_questions'])}
                      for c, v in cells.items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
