#!/usr/bin/env python3
"""Merge first review, audit and adjudication into final judgments and summaries.

Rules:
- final content flags start from the first review;
- resolved audit disagreements overwrite the nine compared fields;
- any recorded completion attempt with finish_reason == 'length' forces
  truncated=true and task/strict/product=false (frozen rubric);
- strict_pass and product_pass are re-derived for consistency.
Writes _control/final-judgments.json, _control/final-review-summary.json and
appends every change to _control/corrections.jsonl.
"""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
SERIES = CONTROL.parent
GENERATION = SERIES / 'generation' / 'runs'
FIELDS = ['task_pass', 'strict_pass', 'product_pass', 'episode_error',
          'unsupported_additions', 'spoiler', 'language_ok', 'codes_correct',
          'sequences_correct']


def load_reviews(directory, packet_manifests):
    result = {}
    for path in sorted(directory.glob('*.json')):
        review = json.loads(path.read_text())
        cell = packet_manifests[review['packet_id']]
        for j in review['judgments']:
            result[(cell, j['case_id'])] = j
    return result


def first_manifest_map():
    mapping, ids = {}, {}
    for manifest_path in sorted((CONTROL / 'packets').glob('*/manifest.json')):
        manifest = json.loads(manifest_path.read_text())
        for packet in manifest['packets']:
            mapping[packet['packet_id']] = manifest['cell']
            ids[(manifest['cell'], packet['packet_id'])] = set(packet['case_ids'])
    return mapping, ids


def main():
    packet_cell, _ = first_manifest_map()
    first = load_reviews(CONTROL / 'reviews', packet_cell)
    audit_selection = json.loads((CONTROL / 'audit-selection.json').read_text())
    audit_cell_map, audit_cells = {}, {}
    for cell, info in audit_selection['cells'].items():
        for packet in info['packets']:
            audit_cell_map[packet['packet_id']] = cell
            for cid in packet['case_ids']:
                audit_cells[(cell, cid)] = packet['packet_id']
    audit = load_reviews(CONTROL / 'audit-reviews-normalized', audit_cell_map)
    adjudication = json.loads((CONTROL / 'adjudication.json').read_text())
    decisions = {(d['cell'], d['case_id']): d for d in adjudication['decisions']}
    if set(decisions) - set(first):
        raise SystemExit(f'unknown adjudicated cases: {set(decisions) - set(first)}')

    runtime = {}
    for cell_dir in sorted(GENERATION.iterdir()):
        results = cell_dir / 'results.json'
        if not results.exists():
            continue
        for record in json.loads(results.read_text()):
            attempts = record['debug'].get('completion_attempts') or []
            runtime[(cell_dir.name, record['case'])] = {
                'truncated_any_attempt': any(a.get('finish_reason') == 'length' for a in attempts),
                'finish_reasons': [a.get('finish_reason') for a in attempts],
                'error': record.get('error'),
            }

    now = datetime.now(timezone.utc).isoformat()
    cases, corrections = [], []
    for key, original in sorted(first.items()):
        cell, cid = key
        judgment = dict(original)
        provenance = {
            'first_review': True,
            'audited': key in audit_cells,
            'audit_packet_id': audit_cells.get(key),
            'adjudicated': key in decisions,
            'truncation_override': False,
        }
        if key in audit and key not in decisions:
            # audit agreed with the first review on every compared field; keep first
            if any(audit[key].get(f) != original.get(f) for f in FIELDS):
                raise SystemExit(f'unresolved audit disagreement: {key}')
        if key in decisions:
            for field, value in decisions[key]['final'].items():
                judgment[field] = value
            judgment['reason'] = 'Adjudicated: ' + decisions[key]['reason']
            judgment['notes'] = 'Resolved between first review and fresh-context audit; see adjudication.json.'
        rt = runtime.get(key)
        if rt is None:
            raise SystemExit(f'no runtime record for {key}')
        judgment['truncated'] = bool(rt['truncated_any_attempt'])
        if judgment['truncated']:
            if judgment.get('task_pass') or judgment.get('strict_pass') or judgment.get('product_pass'):
                provenance['truncation_override'] = True
            judgment['task_pass'] = False
            judgment['strict_pass'] = False
            judgment['product_pass'] = False
        if not judgment.get('task_pass'):
            judgment['strict_pass'] = False
        judgment['product_pass'] = bool(judgment.get('task_pass')) and bool(judgment.get('language_ok'))
        if judgment.get('task_pass') and (judgment.get('unsupported_additions') or judgment.get('spoiler')):
            raise SystemExit(f'inconsistent pass with addition/spoiler: {key}')
        judgment['runtime_success'] = not bool(rt['error'])
        cases.append({'cell': cell, 'case_id': cid, 'judgment': judgment, 'provenance': provenance})

        changed = {f: {'from': original.get(f), 'to': judgment.get(f)}
                   for f in FIELDS if original.get(f) != judgment.get(f)}
        if original.get('truncated') != judgment.get('truncated'):
            changed['truncated'] = {'from': original.get('truncated'), 'to': judgment.get('truncated')}
        if original.get('runtime_success') != judgment.get('runtime_success'):
            changed['runtime_success'] = {'from': original.get('runtime_success'),
                                          'to': judgment.get('runtime_success'),
                                          'reason': 'record-level error only; truncation is reported separately'}
        if changed:
            corrections.append({
                'at': now, 'cell': cell, 'case_id': cid,
                'source': 'audit-adjudication' if key in decisions else 'truncation-normalization',
                'changes': changed,
                'reason': decisions[key]['reason'] if key in decisions
                          else 'Uniform frozen-rubric rule: any length-limited attempt marks the case truncated and fails task_pass.',
            })

    (CONTROL / 'final-judgments.json').write_text(json.dumps({
        'schema': 'model-comparison-final-judgments-v1',
        'adjudication_sha256': hashlib.sha256((CONTROL / 'adjudication.json').read_bytes()).hexdigest(),
        'cases': cases,
    }, ensure_ascii=False, indent=2) + '\n')

    cells = {}
    for item in cases:
        c = cells.setdefault(item['cell'], {
            'cases': 0, 'task_pass': 0, 'strict_pass': 0, 'product_pass': 0,
            'errors': 0, 'truncated': 0, 'episode_error': 0,
            'unsupported_additions': 0, 'spoiler': 0, 'language_fail': 0,
            'codes_checked': 0, 'codes_correct': 0, 'sequences_checked': 0,
            'sequences_correct': 0, 'ambiguous_judgments': 0})
        j = item['judgment']
        c['cases'] += 1
        for field in ('task_pass', 'strict_pass', 'product_pass', 'episode_error',
                      'unsupported_additions', 'spoiler', 'truncated'):
            c[field] += 1 if j.get(field) else 0
        c['errors'] += 1 if j.get('runtime_success') is False else 0
        c['language_fail'] += 1 if j.get('language_ok') is False else 0
        c['ambiguous_judgments'] += 1 if j.get('ambiguous_judgment') else 0
        for field in ('codes_correct', 'sequences_correct'):
            if j.get(field) is not None:
                c[field.replace('_correct', '_checked') if field == 'codes_correct' else 'sequences_checked'] += 1
                c[field] += 1 if j.get(field) else 0
    summary = {'schema': 'model-comparison-final-review-summary-v1', 'cases': len(cases),
               'corrections': len(corrections), 'cells': {}, 'overall': {}}
    for cell, c in sorted(cells.items()):
        c['task_rate'] = round(c['task_pass'] / c['cases'], 4) if c['cases'] else None
        c['product_rate'] = round(c['product_pass'] / c['cases'], 4) if c['cases'] else None
        summary['cells'][cell] = c
    summary['overall'] = {
        'cases': len(cases),
        'task_pass': sum(c['task_pass'] for c in cells.values()),
        'strict_pass': sum(c['strict_pass'] for c in cells.values()),
        'product_pass': sum(c['product_pass'] for c in cells.values()),
        'errors': sum(c['errors'] for c in cells.values()),
        'truncated': sum(c['truncated'] for c in cells.values()),
    }
    summary['overall']['task_rate'] = round(summary['overall']['task_pass'] / len(cases), 4)
    summary['overall']['product_rate'] = round(summary['overall']['product_pass'] / len(cases), 4)
    (CONTROL / 'final-review-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')

    with (CONTROL / 'corrections-final.jsonl').open('w') as fh:
        for correction in corrections:
            fh.write(json.dumps(correction, ensure_ascii=False) + '\n')
    print(json.dumps({'cases': len(cases), 'corrections': len(corrections),
                      'overall': summary['overall']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
