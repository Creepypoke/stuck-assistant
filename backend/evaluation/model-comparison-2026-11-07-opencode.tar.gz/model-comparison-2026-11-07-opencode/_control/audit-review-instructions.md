# Audit review instructions

You are an independent fresh-context auditor. You have not seen the first review.

## Inputs
- Your packet file (path given in the task) contains a rubric, reviewer instructions, and 1-5 cases.
- Each case has: `case_id`, `question`, `expected`, `evidence` (source spans with quotes),
  `retrieved_context_text`, `answer`, `runtime`, `error`, and `binding`.
- Read only your packet and this file. Do not open `_control/generation/`, `_control/packets/`,
  `_control/reviews/`, model metadata, or any other case. Do not search the repository.

## Review rules
- Judge the complete final answer against the question, `expected`, evidence quotes, and
  `retrieved_context_text`. Reasoning is not present and must not be inferred.
- `task_pass`: all requested facts, correct episode/conditions/order/repetition, no material
  unsupported concrete additions, no unnecessary spoilers.
- `strict_pass`: `task_pass` AND source-exact UI labels (no silent GREEN/GRENN normalization).
- `product_pass`: `task_pass` AND `language_ok`.
- Truncated, errored, empty, or clarification-only answers for an answerable question are failures.
- A correct code alone does not prove answer correctness. Check explanations too.
- Codes must be exact, including leading zeros. Use `null` for `codes_correct` and
  `sequences_correct` when the case does not ask for them.
- Unanswerable/ambiguous cases: inventing source facts or picking an arbitrary code fails.
- Set `ambiguous_judgment` to true only when the decision is genuinely borderline, and explain it.

## Output
Write one JSON object to the output path given in the task. No Markdown fences.
- `packet_id`: copy from the packet.
- `packet_sha256`: run `shasum -a 256 <packet path>` and copy the hex digest.
- `reviewer`: the reviewer id given in the task.
- `blind_to_model`: true
- `reviewed_at`: current UTC time in ISO-8601 with `Z`.
- `judgments`: one object per case, in packet order, with exactly these fields:
  `case_id`, `binding` (copy the case's binding object unchanged), `task_pass`, `strict_pass`,
  `product_pass`, `facts_correct`, `codes_correct`, `sequences_correct`, `episode_error`,
  `unsupported_additions`, `spoiler`, `ambiguous_handling` (`ok|fail|na`), `language_ok`,
  `source_exact_ui`, `runtime_success`, `truncated`, `answering_clarification`, `reason`,
  `source_quote_or_span`, `ambiguous_judgment`, `notes`.

After writing the file, reply with only: packet_id, number of judgments, and any case IDs you
consider borderline. Do not paste the JSON.
