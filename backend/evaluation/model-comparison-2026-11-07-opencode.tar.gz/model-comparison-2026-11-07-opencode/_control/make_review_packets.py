#!/usr/bin/env python3
"""Build anonymized review packets from one generation cell.

Packet rules:
- no model name, no run path, no prior scores, no reasoning;
- 3-5 cases, fewer/single for long answers; hard target 48 KiB UTF-8;
- every case carries binding hashes and full answer/context/expected/evidence.

This script only reads generated artifacts and writes packet files.
"""
import argparse
import hashlib
import json
from pathlib import Path

EVAL = Path(__file__).resolve().parent.parent.parent
SERIES = Path(__file__).resolve().parent.parent
RUBRIC = SERIES / '_control/rubric.json'
PROTOCOL = SERIES / '_control/protocol.json'
QUESTIONS = EVAL / 'situations-v1/build-recovered-v3/questions.json'
MAX_BYTES = 48 * 1024
TARGET_BYTES = 40 * 1024


def sha_bytes(b):
    return hashlib.sha256(b).hexdigest()


def sha_file(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_records(cell):
    results = cell / 'results.json'
    if results.exists():
        data = json.loads(results.read_text())
        if isinstance(data, dict):
            data = data.get('records') or data.get('results')
        return data, results, sha_file(results)
    records = []
    for p in sorted((cell / 'records').glob('*.json')):
        records.append(json.loads(p.read_text()))
    if not records:
        raise SystemExit(f'no records in {cell}')
    h = sha_bytes(''.join(json.dumps(r, sort_keys=True, ensure_ascii=False) for r in records).encode())
    return records, cell / 'records', h


def case_payload(rec, question, rubric_sha, protocol_sha):
    answer = rec.get('answer') or ''
    debug = rec.get('debug') or {}
    attempts = debug.get('completion_attempts') or []
    errors = [a for a in attempts if a.get('error')]
    runtime = {
        'attempts': len(attempts),
        'finish_reasons': [a.get('finish_reason') for a in attempts],
        'completion_tokens': [a.get('completion_tokens') for a in attempts],
        'usage_available': all(a.get('usage_available') for a in attempts) if attempts else None,
        'errors': [str(a.get('error')) for a in errors],
        'truncated': any(a.get('finish_reason') == 'length' for a in attempts),
    }
    evidence = []
    for e in question.get('evidence') or []:
        span = e.get('source_span') or {}
        evidence.append({'block_id': span.get('block_id'), 'start': span.get('start'),
                         'end': span.get('end'), 'quote': span.get('quote')})
    payload = {
        'case_id': rec['case'],
        'question': question['question'],
        'expected': question['expected'],
        'evidence': evidence,
        'retrieved_context_text': debug.get('context_text') or '',
        'answer': answer,
        'runtime': runtime,
        'error': rec.get('error'),
        'binding': {
            'protocol_sha256': protocol_sha,
            'rubric_sha256': rubric_sha,
            'record_sha256': sha_bytes(json.dumps(rec, sort_keys=True, ensure_ascii=False).encode()),
            'answer_sha256': sha_bytes(answer.encode()),
            'context_sha256': rec.get('context_sha256'),
            'prompt_sha256': rec.get('prompt_sha256'),
        },
    }
    return payload


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cell', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    ap.add_argument('--max-cases', type=int, default=5)
    ap.add_argument('--min-cases', type=int, default=3)
    args = ap.parse_args()
    rubric_text = json.loads(RUBRIC.read_text())
    protocol = json.loads(PROTOCOL.read_text())
    protocol_sha = sha_file(PROTOCOL)
    questions = {q['id']: q for q in json.loads(QUESTIONS.read_text())}
    records, origin, results_sha = load_records(args.cell)
    order = {q['id']: i for i, q in enumerate(json.loads(QUESTIONS.read_text()))}
    records.sort(key=lambda r: order.get(r['case'], 10**9))
    rubric_sha = sha_file(RUBRIC)
    cases = [case_payload(r, questions[r['case']], rubric_sha, protocol_sha) for r in records]
    args.out.mkdir(parents=True, exist_ok=True)
    packets, current, size = [], [], 0
    for case in cases:
        encoded = len(json.dumps(case, ensure_ascii=False).encode())
        too_big = current and (size + encoded > TARGET_BYTES or len(current) >= args.max_cases)
        enough = len(current) >= args.min_cases
        if too_big and enough:
            packets.append(current)
            current, size = [], 0
        current.append(case)
        size += encoded
    if current:
        packets.append(current)
    manifest = {'cell': args.cell.name, 'source': str(origin), 'results_sha256': results_sha,
                'rubric_sha256': sha_file(RUBRIC), 'protocol_sha256': protocol_sha, 'packets': []}
    for i, packet_cases in enumerate(packets, 1):
        pid = 'pkt-' + sha_bytes(f'{args.cell.name}|{i}|{results_sha}'.encode())[:12]
        packet = {'packet_id': pid, 'rubric': rubric_text,
                  'reviewer_instructions': {
                      'read_full_answer': True,
                      'source': 'expected + evidence quotes + retrieved_context_text',
                      'reasoning': 'excluded by design',
                      'output': 'one JSON judgment per case_id',
                  },
                  'cases': packet_cases}
        path = args.out / f'{pid}.json'
        b = json.dumps(packet, ensure_ascii=False, indent=2).encode()
        path.write_bytes(b + b'\n')
        manifest['packets'].append({'packet_id': pid, 'cell': args.cell.name, 'path': str(path), 'sha256': sha_bytes(b + b'\n'),
                                    'case_ids': [c['case_id'] for c in packet_cases],
                                    'utf8_bytes': len(b),
                                    'over_48k': len(b) > MAX_BYTES})
    (args.out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'cell': args.cell.name, 'records': len(records),
                      'packets': len(packets), 'over_48k': sum(1 for p in manifest['packets'] if p['over_48k']),
                      'results_sha256': results_sha}, ensure_ascii=False))


if __name__ == '__main__':
    main()
