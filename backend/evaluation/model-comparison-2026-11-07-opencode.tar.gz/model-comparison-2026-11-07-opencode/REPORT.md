# Сравнение профилей reasoning-моделей — 2026-11-07 (opencode)

Новая серия: `model-comparison-2026-11-07-opencode`. Baseline `model-comparison-2026-11-07` не перезаписывался, production preset не менялся. Серия сравнивает **профили** (native reasoning + новый бюджет/окно/sampling), а не причинный эффект одного флага.

- Протокол: [`_control/protocol.json`](_control/protocol.json), SHA256 `63032b2daf9f9743d1900fccdbd840387302ca5e70fc4f409ea1062a55e59c15`.
- Условия: 38 вопросов local, 34 oracle; seed 20261104; `default`/`hybrid`/top-5; context cap 2400; `short`; `no_spoilers`; cutoff 0; code_answers false; ctx 16384; max_tokens 4096 с retry 8192; timeout 300 s.
- Профили sampling: qwen2b 1.0/20/.95/0/1.5; minicpm5-1b .9/40/.95/0/0; gemma4-e2b 1.0/64/.95/0/0; jamba3b .6/40/.95/0/0.
- Прогнаны только 4 reasoning-модели. Gemma 3 4B и Phi-4-mini остаются baseline-контролями и не перезапускались.
- Сырые артефакты: [`generation/`](generation/). Полные ответы и ошибки сохранены; неудачные генерации не заменялись.

## Итоги

| Ячейка | task_pass | strict_pass | product_pass | язык | коды | последовательности | trunc | runtime ok | completion tokens (все попытки) | p50 gen, s | Δ task vs baseline | Δ product vs baseline |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| qwen2b-local | 21/38 (55.3%) | 18/38 | 21/38 (55.3%) | 37/38 | 14/14 | 9/9 | 16 | 37/38 | 222135 | 53.4 | −13.2 pp | −13.2 pp |
| qwen2b-oracle | 24/34 (70.6%) | 18/34 | 24/34 (70.6%) | 33/34 | 14/14 | 8/8 | 6 | 34/34 | 133455 | 44.1 | −5.9 pp | −5.9 pp |
| minicpm5-1b-local | 12/38 (31.6%) | 12/38 | 7/38 (18.4%) | 18/38 | 8/14 | 5/8 | 4 | 35/38 | 77325 | 6.5 | −2.6 pp | +7.9 pp |
| minicpm5-1b-oracle | 10/34 (29.4%) | 7/34 | 7/34 (20.6%) | 15/34 | 7/13 | 6/9 | 1 | 34/34 | 23545 | 2.7 | −5.9 pp | +0.0 pp |
| gemma4-e2b-local | 35/38 (92.1%) | 35/38 | 35/38 (92.1%) | 38/38 | 14/14 | 7/7 | 0 | 38/38 | 17495 | 9.0 | +13.2 pp | +15.8 pp |
| gemma4-e2b-oracle | 32/34 (94.1%) | 30/34 | 32/34 (94.1%) | 34/34 | 13/13 | 7/7 | 0 | 34/34 | 13163 | 6.9 | +5.9 pp | +5.9 pp |
| jamba3b-local | 16/38 (42.1%) | 15/38 | 15/38 (39.5%) | 33/38 | 10/14 | 5/8 | 2 | 36/38 | 54722 | 14.9 | +13.2 pp | +13.2 pp |
| jamba3b-oracle | 25/34 (73.5%) | 21/34 | 24/34 (70.6%) | 30/34 | 14/14 | 6/9 | 0 | 34/34 | 24021 | 11.0 | +29.4 pp | +26.5 pp |

Всего: task_pass 175/288 (60.8%), product_pass 165/288 (57.3%). `trunc` — хотя бы одна попытка завершилась `finish_reason=length`; по замороженной рубрике такая ячейка считается провалом task/strict/product. `runtime ok` — только record-level ошибки, без truncation.

### Было → стало (полные ответы)

| Ячейка | task baseline → new | product baseline → new | язык baseline → new | коды baseline → new | последовательности baseline → new |
|---|---|---|---:|---:|---:|
| qwen2b-local | 68.4% → 55.3% | 68.4% → 55.3% | 100% → 97.4% | 92.3% → 100% | 100% → 100% |
| qwen2b-oracle | 76.5% → 70.6% | 76.5% → 70.6% | 100% → 97.1% | 100% → 100% | 85.7% → 100% |
| minicpm5-1b-local | 34.2% → 31.6% | 10.5% → 18.4% | 23.7% → 47.4% | 53.8% → 57.1% | 71.4% → 62.5% |
| minicpm5-1b-oracle | 35.3% → 29.4% | 20.6% → 20.6% | 44.1% → 44.1% | 30.8% → 53.8% | 71.4% → 66.7% |
| gemma4-e2b-local | 78.9% → 92.1% | 76.3% → 92.1% | 97.4% → 100% | 100% → 100% | 100% → 100% |
| gemma4-e2b-oracle | 88.2% → 94.1% | 88.2% → 94.1% | 97.1% → 100% | 100% → 100% | 85.7% → 100% |
| jamba3b-local | 28.9% → 42.1% | 26.3% → 39.5% | 52.6% → 86.8% | 69.2% → 71.4% | 28.6% → 62.5% |
| jamba3b-oracle | 44.1% → 73.5% | 44.1% → 70.6% | 50.0% → 88.2% | 69.2% → 100% | 14.3% → 66.7% |

Разница с baseline включает смену бюджета (4096/8192 против короткого baseline-бюджета), окна и sampling. Это не A/B одного reasoning-флага.

### Изменённые вопросы (task_pass относительно baseline)

- gemma4-e2b-local: улучшены `false-premise`, `fresh-green-items`, `return-small-key`, `second-gail-route`, `unanswerable-easy`; ухудшений нет.
- gemma4-e2b-oracle: улучшены `fresh-green-items`, `gas`, `rick-branch`, `second-gail-route`; ухудшены `beginning`, `second-rick-memory`.
- jamba3b-local: улучшены `b2-ru-plain`, `disc-yellow-leading-zero`, `first-generator`, `gail-pipes`, `gas`, `office-safe`, `planning-disc-safe`, `second-generator`; ухудшены `b1-chip`, `handgun-slides`, `turn-around`.
- jamba3b-oracle: улучшены `b1-b2-distinction`, `battery-acd`, `disc-blue-leading-zero`, `english-first-generator`, `gail-pipes`, `late-rick-id`, `med-pak-l`, `office-id`, `return-small-key`, `rick-pipes`, `second-generator`, `shotgun-location`; ухудшены `handgun-slides`, `panel-code`.
- minicpm5-1b-local: улучшены `b1-chip`, `b2-chips`, `b2-ru-plain`, `office-id`, `unanswerable-easy`; ухудшены `disc-blue-leading-zero`, `emergency-box`, `first-generator`, `gail-pipes`, `planning-disc-safe`, `rick-pipes`.
- minicpm5-1b-oracle: улучшены `office-id`, `second-generator`; ухудшены `first-generator`, `red-box`, `second-rick-memory`, `turn-around`.
- qwen2b-local: улучшены `gail-branch`, `late-gail-id`; ухудшены `disc-blue-leading-zero`, `disc-yellow-leading-zero`, `emergency-box`, `first-generator`, `med-pak-l`, `office-safe`, `second-generator`.
- qwen2b-oracle: улучшены `battery-acd`, `second-rick-memory`, `shotgun-location`; ухудшены `beginning`, `emergency-box`, `late-rick-id`, `planning-disc-safe`, `rick-branch`.

## Сохранённые ошибки

- qwen2b-local: 1 ошибка/усечение (`second-generator`).
- minicpm5-1b-local: 3 ошибки (`b1-b2-distinction`, `office-safe`, `rick-branch`).
- jamba3b-local: 2 ошибки (`false-premise`, `unanswerable-battery-code`).
- Остальные ячейки: 0 record-level ошибок.
- У qwen2b почти все провалы связаны с повторными `length`-попытками даже при завершённом финальном ответе: 16/38 local и 6/34 oracle помечены truncated.

## Аудит review

План зафиксирован до аудита: [`_control/audit-plan.json`](_control/audit-plan.json) (seed `20261108`).

- Страта 1: все 46 случаев, где первый review поставил `ambiguous_judgment=true`.
- Страта 2: по ceil(20%) остальных случаев в каждой ячейке, ранжирование по SHA256(seed|cell|case).
- Итого 97/288 случаев, 22 blinded-пакета без имени модели и без первого review; 22 fresh-context агента.
- Точное совпадение по всем 9 полям: 50/97 (51.5%). Field agreement: task 80.4%, strict 82.5%, product 81.4%, language 90.7%, code 95.9%, sequence 91.8%, spoiler 97.9%.
- 47 случаев с расхождениями разобраны по источнику; решения и причины: [`_control/adjudication.json`](_control/adjudication.json). Итоговые правки: [`_control/corrections-final.jsonl`](_control/corrections-final.jsonl).
- Аудит не является независимой человеческой проверкой: это второй проход той же семьи моделей. Выборка перепредставлена пограничными случаями, поэтому agreement rate не является оценкой всей популяции.
- Механические исправления raw audit (`unsupported_additions` списком, `episode_error` текстом, один транспонированный hash) сохранены в [`_control/audit-normalization.jsonl`](_control/audit-normalization.jsonl); исходные файлы не перезаписаны.

## Langfuse

Проект `walkthrough-backend`, `http://localhost:1488`.

- Raw import: 8 экспериментов, 288 items, 832 runtime/retrieval scores; readback OK до review.
- Gold scores опубликованы после review/аудита: **2479 scores на 288 items, readback OK** ([`_control/gold-publish.json`](_control/gold-publish.json)).
- Gold score names: `gold_strict_pass`, `gold_product_pass`, `gold_truncated`, `task_pass`, `episode_error`, `unsupported_addition`, `spoiler`, `exact_code`, `exact_sequence`, `answer_language_match`.
- `truncated` в gold — единое правило: любая попытка с `finish_reason=length`. Первый review в 4 случаях не применил его; это нормализовано и записано в corrections.

Эксперименты:

| Ячейка | Experiment ID |
|---|---|
| qwen2b-local | `6dd374c03f78b52e577c5f4a5fa1ba47` |
| qwen2b-oracle | `cd9ed3a6f22ab72f8913c0ad83509939` |
| minicpm5-1b-local | `97e18c27acf674985da711d39f35d517` |
| minicpm5-1b-oracle | `b0209b173b2bd5598e1aa186d3cba6bd` |
| gemma4-e2b-local | `f66300d2bebeea67b5d81f47b8597f58` |
| gemma4-e2b-oracle | `4dceb12d2c60ca1c204379a825ef0de8` |
| jamba3b-local | `13b78f622c01c11f3c6a32db3e79abb9` |
| jamba3b-oracle | `b0155ee90748c018ee769140b521dbea` |

Ссылка на проект: <http://localhost:1488/project/walkthrough-backend>.

## Ограничения

- Одна игра, один seed, один диагностический набор из 38 вопросов.
- Сравнение профилей, а не причинный A/B reasoning: одновременно изменены бюджет, окно и sampling.
- Один reviewer и fresh-context аудит той же семьи моделей; независимой слепой человеческой проверки не было.
- Аудит oversamples пограничные случаи.
- Латентность измерена в этом последовательном локальном прогоне; она не сравнивается с production или параллельным baseline.
- Сервер не отдавал отдельный `reasoning_tokens`; зафиксировано только наличие `reasoning_content` во всех попытках. Размер GGUF не является мерой RAM/VRAM.
- Выводы не переносятся на другие игры, корпуса, железо или production preset.

## Артефакты

- [`_control/protocol.json`](_control/protocol.json), [`_control/rubric.json`](_control/rubric.json), [`_control/generation-audit.json`](_control/generation-audit.json), [`_control/review-summary.json`](_control/review-summary.json), [`_control/final-review-summary.json`](_control/final-review-summary.json), [`_control/comparison.json`](_control/comparison.json).
- [`_control/packets/`](_control/packets/), [`_control/reviews/`](_control/reviews/), [`_control/audit-packets/`](_control/audit-packets/), [`_control/audit-reviews/`](_control/audit-reviews/), [`_control/audit-selection.json`](_control/audit-selection.json), [`_control/audit-summary.json`](_control/audit-summary.json).
- Архив с SHA256: `model-comparison-2026-11-07-opencode.tar.gz.sha256` рядом с серией (без весов и секретов).
